Pure Metal Guitar Tone
Plugin Chain:
PRO F.E.T. > Le456 > NadIR > EQ

You will need to have these plugins downloaded and installed before the Reaper .RfxChain will work
Please follow the links to download the free software for the tone:

Ignite Amps PRO F.E.T:
http://www.igniteamps.com/#profet

LePou Le456 Amp Sim:
https://vst4free.com/plugin/963/

Impulse Links:
Sperimental Mesa Impulse 07
https://www.sevenstring.org/threads/big-impulses-package-all-the-best-impulses-in-one-file.184778/page-2

ML Soundlabs "The Best IR In The World"
https://www.youtube.com/watch?v=BI6rovO03DA

Reaper's EQ Plugin:
https://www.reaper.fm/reaplugs/



Please email me at 145recordings@gmail.com if you have any questions!